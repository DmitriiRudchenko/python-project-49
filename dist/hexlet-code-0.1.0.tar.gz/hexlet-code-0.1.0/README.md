### Hexlet tests and linter status:
[![Actions Status](https://github.com/DmitriiRudchenko/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/DmitriiRudchenko/python-project-49/actions)

### Codeclimate Maintainability :
<a href="https://codeclimate.com/github/DmitriiRudchenko/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/2bee17be6128432b591f/maintainability" /></a>

# asciinema break-even :
<a href="https://asciinema.org/a/m0tgPiOAp0T9VprmvkP8mJVFn" target="_blank"><img src="https://asciinema.org/a/m0tgPiOAp0T9VprmvkP8mJVFn.svg" /></a>

# asciinema break-calc :
<a href="https://asciinema.org/a/RPupVrB2zyfmH165hCexyVqlV" target="_blank"><img src="https://asciinema.org/a/RPupVrB2zyfmH165hCexyVqlV.svg" /></a>