# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['brain_games', 'brain_games.games', 'brain_games.scripts']

package_data = \
{'': ['*']}

install_requires = \
['prompt>=0.4.1,<0.5.0', 'sympy>=1.11.1,<2.0.0']

entry_points = \
{'console_scripts': ['brain-calc = brain_games.scripts.brain_calc:main',
                     'brain-even = brain_games.scripts.brain_even:main',
                     'brain-games = brain_games.scripts.brain_games:main',
                     'brain-gcd = brain_games.scripts.brain_gcd:main',
                     'brain-prime = brain_games.scripts.brain_prime:main',
                     'brain-progression = '
                     'brain_games.scripts.brain_progression:main']}

setup_kwargs = {
    'name': 'hexlet-code',
    'version': '0.1.0',
    'description': '',
    'long_description': '### Hexlet tests and linter status:\n[![Actions Status](https://github.com/DmitriiRudchenko/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/DmitriiRudchenko/python-project-49/actions)\n\n### Codeclimate Maintainability :\n<a href="https://codeclimate.com/github/DmitriiRudchenko/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/2bee17be6128432b591f/maintainability" /></a>\n\n## Install\n```\ngit clone https://github.com/DmitriiRudchenko/python-project-49\ncd python-project-49\nmake package-install\n```\n## Usage\n* Even number: `brain-even`\n* Calculate the expression: `brain-calc`\n* Greatest common divisor: `brain-gcd`\n* Guess missing number: `brain-progression`\n* Prime number: `brain-prime`\n\n## Description\n«Игры разума» — набор из пяти консольных игр, построенных по принципу популярных мобильных приложений для прокачки мозга. Каждая игра задает вопросы, на которые нужно дать правильные ответы. После трех правильных ответов считается, что игра пройдена. Неправильные ответы завершают игру и предлагают пройти ее заново.\n### brain-even\nПроверка на чётность. Суть игры: пользователю показывается случайное число. И ему нужно ответить yes, если число чётное, или no — если нечётное.\n<a href="https://asciinema.org/a/m0tgPiOAp0T9VprmvkP8mJVFn" target="_blank"><img src="https://asciinema.org/a/m0tgPiOAp0T9VprmvkP8mJVFn.svg" /></a>\n\n### brain-calc\nКалькулятор. Суть игры: пользователю показывается случайное математическое выражение, например 35 + 16, которое нужно вычислить и записать правильный ответ.\n<a href="https://asciinema.org/a/RPupVrB2zyfmH165hCexyVqlV" target="_blank"><img src="https://asciinema.org/a/RPupVrB2zyfmH165hCexyVqlV.svg" /></a>\n\n### brain-gcd\nНаибольший общий делителью Суть игры: пользователю показывается два случайных числа, например, 25 50. Пользователь должен вычислить и ввести наибольший общий делитель этих чисел.\n<a href="https://asciinema.org/a/enXvsetUt2DJIN6ZfLovThH3x" target="_blank"><img src="https://asciinema.org/a/enXvsetUt2DJIN6ZfLovThH3x.svg" /></a>\n\n### brain-progression\nАрифметическая прогрессия. Суть игры: показываем игроку ряд чисел, образующий арифметическую прогрессию, заменив любое из чисел двумя точками. Игрок должен определить это число.\n<a href="https://asciinema.org/a/2szrwC8CcyoYfH1MXnUZ8s9IE" target="_blank"><img src="https://asciinema.org/a/2szrwC8CcyoYfH1MXnUZ8s9IE.svg" /></a>\n\n### brain-prime\nПростое число. Суть игры: пользователю показывается случайное число. И ему нужно ответить yes, если число простое, или no — если не простое.\n<a href="https://asciinema.org/a/ZmhaEzEuHszmPE2uWKUMHrIDD" target="_blank"><img src="https://asciinema.org/a/ZmhaEzEuHszmPE2uWKUMHrIDD.svg" /></a>',
    'author': 'Dmitrii Rudchenko',
    'author_email': 'rudchenko.d.v@gmail.com',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.9,<4.0',
}


setup(**setup_kwargs)
