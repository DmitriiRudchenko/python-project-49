import random
import prompt

name = ''
number_of_answers = 0 

def welcome_user():
    global name
    print('Welcome to the Brain Games!')
    name1 = prompt.string('May I have your name? ')
    print(f'Hello, {name1}!')
    name = name1