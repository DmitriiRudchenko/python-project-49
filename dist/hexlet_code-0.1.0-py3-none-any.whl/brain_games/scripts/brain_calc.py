#!/usr/bin/env python3

from brain_games.games.main_logic import welcome_user

import random
import prompt

def calc_game():
    global number_of_answers
    number_f = random.randint(0, 50)
    meaning = ''
    print(f'Qestion: {number_f}')
    
    
    if number_f % 2 == 0:
        meaning = 'yes'
    else:
        meaning = 'no'


    answer = prompt.string('Your answer: ')

    
    if number_of_answers < 2:
        if answer == meaning:
            print('Correct!')
            number_of_answers += 1
            even_game()
        
        if answer != meaning:
            print(f"'{answer}' is wrong answer ;(. Correct answer was '{meaning}'.\nLet's try again, {name}")
    
    else:
        print(f'Congratulations, {name}!')


def main():
    print('Answer "yes" if the number is even, otherwise answer "no".')
    calc_game()


if __name__ == '__main__':
    main()